"""
parser.py — Pattern-matching vulnerability detector.

Strategy:
  - Normalise input text.
  - Score each vulnerability type by counting how many of its keyword phrases
    appear in the text (longer phrases carry higher weight).
  - Return the highest-scoring type, or "Unknown" if nothing matches.
"""

from patterns import VULNERABILITY_PATTERNS


def _normalise(text: str) -> str:
    return text.lower().replace("-", " ")


def detect_vulnerability(text: str) -> str:
    """
    Identify the most likely vulnerability type from a description string.

    Returns the vulnerability type name (str) or "Unknown".
    """
    normalised = _normalise(text)
    scores: dict[str, float] = {}

    for vuln_type, keywords in VULNERABILITY_PATTERNS.items():
        score = 0.0
        for kw in keywords:
            if kw in normalised:
                # Weight longer / more specific phrases more heavily
                score += len(kw.split())
        if score > 0:
            scores[vuln_type] = score

    if not scores:
        return "Unknown"

    # Return the type with the highest accumulated score
    return max(scores, key=lambda k: scores[k])


def detect_all_vulnerabilities(text: str) -> list[tuple[str, float]]:
    """
    Return ALL matching vulnerability types, sorted by descending score.
    Useful for descriptions that touch multiple vulnerability classes.
    """
    normalised = _normalise(text)
    scores: dict[str, float] = {}

    for vuln_type, keywords in VULNERABILITY_PATTERNS.items():
        score = 0.0
        for kw in keywords:
            if kw in normalised:
                score += len(kw.split())
        if score > 0:
            scores[vuln_type] = score

    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


# ── Quick self-test ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    tests = [
        "A buffer overflow vulnerability exists due to improper bounds checking.",
        "SQL injection vulnerability in login module exposes sensitive database information.",
        "Cross site scripting in comment section allows execution of malicious scripts.",
    ]
    for t in tests:
        print(f"  [{detect_vulnerability(t)}]  {t[:60]}...")
