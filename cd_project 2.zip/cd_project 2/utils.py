"""
utils.py — Helper utilities for the CVE Vulnerability Parser project.

Includes:
  - CVE loader (plain text, one per line)
  - JSON result writer
  - Statistics generator
  - Terminal report printer with colour support
  - Summary table builder
"""

from __future__ import annotations
import json
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path


# ── ANSI colour helpers ──────────────────────────────────────────────────────

_USE_COLOUR = sys.stdout.isatty() or os.environ.get("FORCE_COLOR")

COLOURS = {
    "reset":   "\033[0m",
    "bold":    "\033[1m",
    "red":     "\033[31m",
    "yellow":  "\033[33m",
    "green":   "\033[32m",
    "cyan":    "\033[36m",
    "magenta": "\033[35m",
    "white":   "\033[37m",
    "grey":    "\033[90m",
}

SEVERITY_COLOUR = {
    "Critical": "red",
    "High":     "red",
    "Medium":   "yellow",
    "Low":      "green",
    "Unknown":  "grey",
}


def _c(text: str, colour: str) -> str:
    if not _USE_COLOUR:
        return text
    return f"{COLOURS.get(colour, '')}{text}{COLOURS['reset']}"


def _bold(text: str) -> str:
    return _c(text, "bold") if _USE_COLOUR else text


# ── File I/O ─────────────────────────────────────────────────────────────────

def load_cves(filepath: str) -> list[str]:
    """
    Load CVE descriptions from a plain-text file (one description per line).
    Blank lines and lines starting with '#' are ignored.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(
            f"CVE data file not found: '{filepath}'\n"
            f"Please create 'data/cves.txt' with one CVE description per line."
        )

    cves: list[str] = []
    with path.open(encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if line and not line.startswith("#"):
                cves.append(line)

    if not cves:
        raise ValueError(f"No CVE descriptions found in '{filepath}'.")

    return cves


def save_results(results: list[dict], output_path: str = "output.json") -> None:
    """Serialise results list to a formatted JSON file."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=4, ensure_ascii=False)
    print(_c(f"\n✔  Results written to '{output_path}'", "green"))


# ── Statistics ───────────────────────────────────────────────────────────────

def generate_statistics(results: list[dict]) -> dict:
    """
    Compute aggregated statistics from parsed IR records.

    Returns a dict with:
      - by_type        : {vuln_type: count}
      - by_severity    : {severity: count}
      - by_component   : {component: count}
      - avg_confidence : float
      - total          : int
    """
    by_type: Counter = Counter()
    by_severity: Counter = Counter()
    by_component: Counter = Counter()
    confidence_sum = 0

    for r in results:
        by_type[r.get("vulnerability_type", "Unknown")] += 1
        by_severity[r.get("severity", "Unknown")] += 1
        by_component[r.get("affected_component", "Unknown")] += 1
        confidence_sum += r.get("confidence", 0)

    return {
        "total": len(results),
        "by_type": dict(by_type.most_common()),
        "by_severity": dict(by_severity.most_common()),
        "by_component": dict(by_component.most_common()),
        "avg_confidence": round(confidence_sum / len(results), 1) if results else 0,
    }


# ── Terminal printer ──────────────────────────────────────────────────────────

def _severity_tag(severity: str) -> str:
    col = SEVERITY_COLOUR.get(severity, "grey")
    return _c(f"[{severity.upper()}]", col)


def print_results(results: list[dict]) -> None:
    """Pretty-print each IR record to the terminal."""
    print("\n" + _bold("=" * 62))
    print(_bold("   CVE VULNERABILITY MAPPING — PARSED RESULTS"))
    print(_bold("=" * 62))

    for i, r in enumerate(results, 1):
        sev_tag = _severity_tag(r.get("severity", "Unknown"))
        vtype   = _c(r.get("vulnerability_type", "Unknown"), "cyan")
        conf    = r.get("confidence", 0)

        print(f"\n{_bold(f'[{i:02d}]')} {sev_tag} {vtype}")
        print(f"     {_c('ID          :', 'grey')} {r.get('id', 'N/A')}")
        print(f"     {_c('Description :', 'grey')} {r['description'][:90]}{'…' if len(r['description']) > 90 else ''}")
        print(f"     {_c('Root Cause  :', 'grey')} {r.get('root_cause', 'Unknown')}")
        print(f"     {_c('Impact      :', 'grey')} {r.get('impact', 'Unknown')}")
        print(f"     {_c('Component   :', 'grey')} {r.get('affected_component', 'Unknown')}")
        print(f"     {_c('CWE         :', 'grey')} {r.get('cwe_id', 'N/A')}")
        print(f"     {_c('Confidence  :', 'grey')} {conf}%")

        constructs = r.get("linked_code_constructs", [])
        if constructs:
            print(f"     {_c('Constructs  :', 'grey')} {', '.join(constructs[:6])}")

        mitigation = r.get("mitigation", "")
        if mitigation:
            print(f"     {_c('Mitigation  :', 'grey')} {mitigation[:110]}{'…' if len(mitigation) > 110 else ''}")


def print_statistics(stats: dict) -> None:
    """Print a formatted statistics report."""
    print("\n" + _bold("=" * 62))
    print(_bold("   VULNERABILITY STATISTICS"))
    print(_bold("=" * 62))

    print(f"\n  {_bold('Total CVEs processed:')} {stats['total']}")
    print(f"  {_bold('Average confidence  :')} {stats['avg_confidence']}%\n")

    # By type
    print(_bold("  ── By Vulnerability Type ──────────────────────"))
    for vtype, count in stats["by_type"].items():
        bar = "█" * count
        print(f"  {vtype:<28} {_c(bar, 'cyan')} {count}")

    # By severity
    print(_bold("\n  ── By Severity ────────────────────────────────"))
    for sev, count in stats["by_severity"].items():
        col = SEVERITY_COLOUR.get(sev, "grey")
        bar = "█" * count
        print(f"  {sev:<12} {_c(bar, col)} {count}")

    # By component
    print(_bold("\n  ── By Affected Component ──────────────────────"))
    for comp, count in stats["by_component"].items():
        print(f"  {comp:<28} {count}")

    print()
