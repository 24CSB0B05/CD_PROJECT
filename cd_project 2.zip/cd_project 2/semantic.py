"""
semantic.py — Semantic analysis layer.

Extracts:
  - root_cause   : underlying programming / design flaw
  - impact       : what an attacker can achieve
  - affected_component : part of the system at risk
  - severity     : Low / Medium / High / Critical
  - confidence   : 0–100 estimate of how certain the extraction is
"""

from __future__ import annotations

# ── Rule tables ──────────────────────────────────────────────────────────────

ROOT_CAUSE_RULES: list[tuple[list[str], str]] = [
    # (trigger keywords, label)
    (["bounds checking", "boundary checking", "out of bounds"], "Boundary checking failure"),
    (["improper", "unsanitized", "unvalidated", "without sanitiz"], "Improper input validation"),
    (["memory management", "memory corruption", "use after free",
      "dangling pointer", "integer overflow", "arithmetic"], "Memory management issue"),
    (["path traversal", "path validation", "directory traversal",
      "crafted path"], "Improper path validation"),
    (["authentication", "credential", "session validation"], "Authentication validation flaw"),
    (["malformed", "improper input handling"], "Improper input handling"),
    (["encoding", "output encoding", "rendered without"], "Missing output encoding"),
    (["race condition", "concurrent", "time of check"], "Synchronisation / race condition"),
    (["privilege", "permission"], "Improper privilege management"),
    (["command injection", "shell command", "os command"], "Unsafe command execution"),
]

IMPACT_RULES: list[tuple[list[str], str, str]] = [
    # (trigger keywords, impact label, severity bump)
    (["execute arbitrary code", "arbitrary code execution",
      "remote code execution", "rce"], "Arbitrary code execution", "High"),
    (["privilege escalation", "gain elevated", "escalate"], "Privilege escalation", "High"),
    (["denial of service", "service disruption",
      "crash the server", "crash the system", "crash the browser",
      "unavailable"], "Service disruption", "Medium"),
    (["unauthorized access", "sensitive information", "access restricted",
      "sensitive database"], "Unauthorized access", "Medium"),
    (["script injection", "malicious script", "client side script",
      "xss", "cross site scripting"], "Client-side script execution", "Medium"),
    (["data leakage", "data exfiltration", "sensitive data"], "Data exfiltration", "High"),
    (["memory corruption"], "Memory corruption", "High"),
]

COMPONENT_RULES: list[tuple[list[str], str]] = [
    (["database", "sql", "query"], "Database"),
    (["browser", "web browser"], "Web browser"),
    (["server", "http server", "web server"], "Server"),
    (["memory management", "heap", "stack", "allocat"], "Memory management"),
    (["kernel", "operating system", "os "], "Operating system kernel"),
    (["function", "input validation", "library"], "Application function"),
    (["login", "authentication module", "session"], "Authentication module"),
    (["file system", "directory", "path", "file"], "File system"),
    (["network", "packet", "socket"], "Network layer"),
]

SEVERITY_KEYWORDS = {
    "Critical": ["remote code execution", "rce", "privilege escalation",
                 "critical", "unauthenticated"],
    "High": ["arbitrary code", "code execution", "memory corruption",
             "data exfiltration", "high"],
    "Low": ["information disclosure", "low severity", "minor"],
}


def _match(text: str, keywords: list[str]) -> bool:
    return any(kw in text for kw in keywords)


def _derive_severity(text: str, impact: str) -> str:
    for level, kws in SEVERITY_KEYWORDS.items():
        if _match(text, kws):
            return level
    # Impact-based fallback
    if impact == "Arbitrary code execution":
        return "High"
    if impact in ("Service disruption", "Unauthorized access",
                  "Client-side script execution"):
        return "Medium"
    return "Medium"


def semantic_analysis(text: str) -> dict:
    """
    Analyse a CVE description and return a dictionary of semantic fields.

    Fields
    ------
    root_cause, impact, affected_component, severity, confidence
    """
    lowered = text.lower().replace("-", " ")

    # ── Root cause ──────────────────────────────────────────────────────────
    root_cause = "Unknown"
    for triggers, label in ROOT_CAUSE_RULES:
        if _match(lowered, triggers):
            root_cause = label
            break

    # ── Impact ──────────────────────────────────────────────────────────────
    impact = "Unknown"
    severity_from_impact = "Medium"
    for triggers, label, sev in IMPACT_RULES:
        if _match(lowered, triggers):
            impact = label
            severity_from_impact = sev
            break

    # ── Affected component ──────────────────────────────────────────────────
    affected_component = "Unknown"
    for triggers, label in COMPONENT_RULES:
        if _match(lowered, triggers):
            affected_component = label
            break

    # ── Severity (text-keyword takes priority, then impact-based) ───────────
    severity = "Medium"
    for level, kws in SEVERITY_KEYWORDS.items():
        if _match(lowered, kws):
            severity = level
            break
    else:
        severity = severity_from_impact

    # ── Confidence heuristic ────────────────────────────────────────────────
    known = sum([
        root_cause != "Unknown",
        impact != "Unknown",
        affected_component != "Unknown",
    ])
    confidence = round((known / 3) * 100)

    return {
        "root_cause": root_cause,
        "impact": impact,
        "affected_component": affected_component,
        "severity": severity,
        "confidence": confidence,
    }


# ── Quick self-test ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    import json
    samples = [
        "A buffer overflow vulnerability exists due to improper bounds checking "
        "allowing attackers to execute arbitrary code.",
        "SQL injection vulnerability in login module exposes sensitive database information.",
        "Use-after-free bug in browser engine allows attackers to crash the browser.",
    ]
    for s in samples:
        result = semantic_analysis(s)
        print(json.dumps({"desc": s[:60], **result}, indent=2))
        print()
