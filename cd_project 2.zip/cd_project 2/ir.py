"""
ir.py — Intermediate Representation (IR) builder.

Transforms raw parser + semantic output into a structured IR dictionary
that acts as the canonical record for each CVE entry.  The IR is later
serialised to JSON or fed into the report generator.
"""

from __future__ import annotations
import hashlib
import re
from datetime import datetime
from patterns import VULNERABILITY_METADATA


def _generate_id(description: str) -> str:
    """Deterministic short ID derived from the description text."""
    digest = hashlib.md5(description.strip().encode()).hexdigest()
    return f"CVE-PARSE-{digest[:8].upper()}"


def _extract_code_constructs(description: str, vuln_type: str) -> list[str]:
    """
    Heuristically identify code constructs or functions mentioned in the
    description that are likely related to the vulnerability.
    """
    constructs: list[str] = []
    text = description.lower()

    CONSTRUCT_HINTS = {
        "Buffer Overflow": ["strcpy", "sprintf", "gets", "memcpy", "strcat",
                             "scanf", "buffer", "array", "malloc", "alloc"],
        "SQL Injection":   ["query", "execute", "select", "insert", "update",
                             "delete", "prepare", "cursor", "fetchall"],
        "Cross Site Scripting": ["innerhtml", "document.write", "eval",
                                  "outerhtml", "render", "template"],
        "Use After Free":  ["free()", "delete", "malloc", "realloc", "pointer",
                             "destructor", "dealloc"],
        "Command Injection": ["system()", "exec()", "popen()", "subprocess",
                               "shell_exec", "os.system"],
    }

    hints = CONSTRUCT_HINTS.get(vuln_type, [])
    for hint in hints:
        if hint.rstrip("()") in text:
            constructs.append(hint)

    # Also pull any CamelCase or snake_case identifiers that look like function names
    func_pattern = re.compile(r"\b([a-z][a-z0-9]*(?:_[a-z0-9]+)+|[A-Z][a-zA-Z0-9]+)\b")
    found = func_pattern.findall(description)
    constructs.extend([f for f in found if f not in constructs][:5])

    return list(dict.fromkeys(constructs))  # deduplicate, preserve order


def build_ir(
    description: str,
    vuln_type: str,
    semantics: dict,
    *,
    source_id: str | None = None,
) -> dict:
    """
    Build the canonical Intermediate Representation for one CVE entry.

    Parameters
    ----------
    description : Raw CVE description string.
    vuln_type   : Detected vulnerability type from parser.
    semantics   : Output dict from semantic_analysis().
    source_id   : Optional external CVE-ID (e.g. "CVE-2023-1234").

    Returns
    -------
    dict — structured IR record.
    """
    meta = VULNERABILITY_METADATA.get(vuln_type, VULNERABILITY_METADATA["Unknown"])
    code_constructs = _extract_code_constructs(description, vuln_type)

    ir = {
        # ── Identity ──────────────────────────────────────────────────────
        "id": source_id or _generate_id(description),
        "parsed_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),

        # ── Core fields ───────────────────────────────────────────────────
        "description": description.strip(),
        "vulnerability_type": vuln_type,
        "root_cause": semantics["root_cause"],
        "impact": semantics["impact"],
        "affected_component": semantics["affected_component"],
        "severity": semantics["severity"],
        "confidence": semantics.get("confidence", 0),

        # ── Enrichment from metadata ──────────────────────────────────────
        "cwe_id": meta["cwe"],
        "mitigation": meta["mitigation"],
        "references": meta["references"],

        # ── Code-construct linkage ────────────────────────────────────────
        "linked_code_constructs": code_constructs,
    }

    return ir


# ── Quick self-test ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    import json
    from semantic import semantic_analysis

    desc = (
        "A buffer overflow vulnerability exists in the input validation function "
        "due to improper bounds checking allowing attackers to execute arbitrary code."
    )
    sem = semantic_analysis(desc)
    record = build_ir(desc, "Buffer Overflow", sem)
    print(json.dumps(record, indent=2))
