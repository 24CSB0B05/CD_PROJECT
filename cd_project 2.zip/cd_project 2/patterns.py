VULNERABILITY_PATTERNS = {
    "Buffer Overflow": [
        "buffer overflow",
        "heap buffer overflow",
        "stack buffer overflow",
        "stack overflow",
        "out of bounds",
        "memory overflow",
        "heap overflow",
        "bounds checking",
    ],
    "SQL Injection": [
        "sql injection",
        "database query",
        "unsanitized input",
        "database injection",
        "sql",
        "database",
    ],
    "Cross Site Scripting": [
        "cross site scripting",
        "cross-site scripting",
        "xss",
        "script injection",
        "malicious script",
        "script execution",
    ],
    "Use After Free": [
        "use after free",
        "use-after-free",
        "dangling pointer",
        "freed memory",
    ],
    "Directory Traversal": [
        "directory traversal",
        "path traversal",
        "../",
        "restricted files",
        "crafted path",
    ],
    "Authentication Bypass": [
        "authentication bypass",
        "bypass authentication",
        "credential validation",
        "session validation",
        "unauthorized access",
        "improper credential",
    ],
    "Integer Overflow": [
        "integer overflow",
        "arithmetic overflow",
        "arithmetic operations",
    ],
    "Denial Of Service": [
        "denial of service",
        "dos attack",
        "service disruption",
        "resource exhaustion",
        "malformed",
    ],
    "Command Injection": [
        "command injection",
        "os command injection",
        "shell command execution",
        "arbitrary command",
    ],
    "Race Condition": [
        "race condition",
        "concurrent access issue",
        "time of check",
        "time of use",
    ],
    "Privilege Escalation": [
        "privilege escalation",
        "gain elevated privileges",
        "escalate privileges",
    ],
}

VULNERABILITY_METADATA = {
    "Buffer Overflow": {
        "cwe": "CWE-120",
        "mitigation": "Implement bounds checking, use safe string functions, enable stack canaries and ASLR.",
        "references": ["https://cwe.mitre.org/data/definitions/120.html"],
    },
    "SQL Injection": {
        "cwe": "CWE-89",
        "mitigation": "Use parameterized queries / prepared statements. Sanitize and validate all user inputs.",
        "references": ["https://cwe.mitre.org/data/definitions/89.html"],
    },
    "Cross Site Scripting": {
        "cwe": "CWE-79",
        "mitigation": "Encode all output, use Content-Security-Policy headers, validate and sanitize inputs.",
        "references": ["https://cwe.mitre.org/data/definitions/79.html"],
    },
    "Use After Free": {
        "cwe": "CWE-416",
        "mitigation": "Nullify pointers after freeing, use smart pointers, employ memory-safe languages where possible.",
        "references": ["https://cwe.mitre.org/data/definitions/416.html"],
    },
    "Directory Traversal": {
        "cwe": "CWE-22",
        "mitigation": "Validate and canonicalize file paths, restrict access to allowed directories only.",
        "references": ["https://cwe.mitre.org/data/definitions/22.html"],
    },
    "Authentication Bypass": {
        "cwe": "CWE-287",
        "mitigation": "Implement robust authentication checks, use secure session management, enforce MFA.",
        "references": ["https://cwe.mitre.org/data/definitions/287.html"],
    },
    "Integer Overflow": {
        "cwe": "CWE-190",
        "mitigation": "Validate arithmetic inputs, use integer overflow detection libraries, use safe integer types.",
        "references": ["https://cwe.mitre.org/data/definitions/190.html"],
    },
    "Denial Of Service": {
        "cwe": "CWE-400",
        "mitigation": "Implement rate limiting, validate and sanitize all incoming data, use timeouts and resource limits.",
        "references": ["https://cwe.mitre.org/data/definitions/400.html"],
    },
    "Command Injection": {
        "cwe": "CWE-78",
        "mitigation": "Avoid shell calls with user input; use safe APIs, whitelist allowed commands.",
        "references": ["https://cwe.mitre.org/data/definitions/78.html"],
    },
    "Race Condition": {
        "cwe": "CWE-362",
        "mitigation": "Use proper locking mechanisms, atomic operations, and thread-safe data structures.",
        "references": ["https://cwe.mitre.org/data/definitions/362.html"],
    },
    "Privilege Escalation": {
        "cwe": "CWE-269",
        "mitigation": "Apply least-privilege principles, validate privilege levels on every sensitive operation.",
        "references": ["https://cwe.mitre.org/data/definitions/269.html"],
    },
    "Unknown": {
        "cwe": "N/A",
        "mitigation": "Manual review required. Refer to OWASP Top 10 and NIST guidelines.",
        "references": [],
    },
}
