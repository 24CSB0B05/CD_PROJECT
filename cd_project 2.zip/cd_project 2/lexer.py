"""
lexer.py — Tokenizes and cleans CVE description text.

Phases:
  1. Lowercasing
  2. Punctuation normalization (hyphens preserved as spaces for compound terms)
  3. Stop-word removal
  4. Token list production
"""

import re

STOP_WORDS = {
    "a", "an", "the", "is", "in", "it", "of", "to", "and", "or", "for",
    "with", "on", "at", "by", "this", "that", "are", "was", "be", "as",
    "from", "when", "which", "due", "can", "via", "its", "into", "has",
    "have", "been", "not", "but", "also", "any", "all", "such", "so",
    "their", "they", "them", "will", "would", "could", "should", "may",
    "then", "than", "there", "these", "those", "using", "used", "use",
    "allow", "allows", "cause", "causes", "lead", "leads",
}


def clean_text(text: str) -> str:
    """Lowercase, normalize hyphens, strip special characters."""
    text = text.lower()
    # Replace hyphens with spaces so compound terms tokenize naturally
    text = text.replace("-", " ")
    # Remove everything except alphanumerics and spaces
    text = re.sub(r"[^a-z0-9 ]", " ", text)
    # Collapse multiple spaces
    text = re.sub(r"\s+", " ", text).strip()
    return text


def tokenize(text: str) -> list[str]:
    """Return a filtered list of meaningful tokens from a CVE description."""
    cleaned = clean_text(text)
    raw_tokens = cleaned.split()
    tokens = [t for t in raw_tokens if t not in STOP_WORDS and len(t) > 1]
    return tokens


def tokenize_raw(text: str) -> list[str]:
    """Return all tokens without stop-word filtering (used by semantic layer)."""
    cleaned = clean_text(text)
    return cleaned.split()


# ── Quick self-test ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    sample = (
        "A buffer overflow vulnerability exists in the input validation function "
        "due to improper bounds checking allowing attackers to execute arbitrary code."
    )
    print("Filtered tokens:", tokenize(sample))
    print("Raw tokens     :", tokenize_raw(sample))
