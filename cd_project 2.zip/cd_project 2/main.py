"""
main.py — Entry point for the CVE Vulnerability Description Parser.

Pipeline
--------
  Raw text  →  Lexer (tokenise)
            →  Parser (detect vulnerability type via pattern matching)
            →  Semantic Analysis (extract root cause, impact, component, severity)
            →  IR Builder (assemble structured record, enrich with CWE & mitigations)
            →  Output (JSON file + formatted terminal report)

Usage
-----
  python main.py                        # reads data/cves.txt, writes output.json
  python main.py --input my_cves.txt   # custom input file
  python main.py --output results.json # custom output file
  python main.py --quiet               # suppress terminal output
"""

from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

from lexer import tokenize
from parser import detect_vulnerability, detect_all_vulnerabilities
from semantic import semantic_analysis
from ir import build_ir
from utils import (
    load_cves,
    save_results,
    generate_statistics,
    print_results,
    print_statistics,
)


# ── Core pipeline ─────────────────────────────────────────────────────────────

def process_cve(cve_text: str, source_id: str | None = None) -> dict:
    """
    Run the full compilation pipeline on a single CVE description.

    Returns a fully enriched IR dictionary.
    """
    # Phase 1 – Lexical analysis: tokenise the raw text
    tokens = tokenize(cve_text)  # noqa: F841  (available for extension / debug)

    # Phase 2 – Parsing: pattern-match to a vulnerability type
    vuln_type = detect_vulnerability(cve_text)

    # Phase 3 – Semantic analysis: extract root cause, impact, component, severity
    semantics = semantic_analysis(cve_text)

    # Phase 4 – IR construction: assemble + enrich the record
    ir = build_ir(cve_text, vuln_type, semantics, source_id=source_id)

    return ir


# ── CLI argument handling ─────────────────────────────────────────────────────

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="CVE Vulnerability Description Parser — maps CVE text to vulnerability patterns.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--input", "-i",
        default="cves.txt",
        metavar="FILE",
        help="Path to CVE description file (default: data/cves.txt)",
    )
    parser.add_argument(
        "--output", "-o",
        default="output.json",
        metavar="FILE",
        help="Path for JSON output file (default: output.json)",
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress terminal output; only write the JSON file",
    )
    parser.add_argument(
        "--json-only",
        action="store_true",
        help="Print raw JSON to stdout and exit (skips terminal report)",
    )
    return parser.parse_args()


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> int:
    args = parse_args()

    # ── Load CVE descriptions ─────────────────────────────────────────────
    try:
        cves = load_cves(args.input)
    except (FileNotFoundError, ValueError) as exc:
        print(f"\n[ERROR] {exc}", file=sys.stderr)
        return 1

    if not args.quiet:
        print(f"\n  Loaded {len(cves)} CVE description(s) from '{args.input}' …")

    # ── Process each description through the pipeline ─────────────────────
    results: list[dict] = []
    for idx, cve_text in enumerate(cves, 1):
        source_id = f"CVE-SAMPLE-{idx:04d}"
        record = process_cve(cve_text, source_id=source_id)
        results.append(record)

    # ── Persist results to JSON ───────────────────────────────────────────
    save_results(results, args.output)

    # ── JSON-only mode ────────────────────────────────────────────────────
    if args.json_only:
        print(json.dumps(results, indent=4))
        return 0

    # ── Terminal report ───────────────────────────────────────────────────
    if not args.quiet:
        print_results(results)
        stats = generate_statistics(results)
        print_statistics(stats)

    return 0


if __name__ == "__main__":
    sys.exit(main())
